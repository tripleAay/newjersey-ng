import Link from "next/link";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";

import { requireStoreAdmin } from "@/app/lib/newjersey/auth/admin";
import { getSupabaseAdmin } from "@/app/lib/newjersey/supabase/admin";

export const dynamic = "force-dynamic";

const field =
  "mt-2 min-h-12 w-full rounded-xl border border-black/15 bg-white px-4 py-3 text-base outline-none focus:border-[#F58220]";

async function saveJersey(form: FormData) {
  "use server";

  await requireStoreAdmin();

  function fail(message: string): never {
    redirect(`/admin/jerseys?error=${encodeURIComponent(message)}`);
  }

  function text(key: string, max: number) {
    const value = form.get(key);

    if (typeof value !== "string" || value.trim().length > max) {
      fail(`Invalid ${key.replaceAll("_", " ")}.`);
    }

    return value.trim();
  }

  function amount(key: string) {
    const raw = text(key, 20);

    if (!/^\d{1,8}(\.\d{1,2})?$/.test(raw)) {
      fail("Enter valid prices with no more than two decimal places.");
    }

    return Number(raw);
  }

  const id = text("product_id", 19);

  if (!/^[1-9]\d*$/.test(id)) fail("Choose a valid product.");

  const team = text("team", 100);
  const season = text("season", 40);
  const kit = text("kit", 10);
  const sizes = [
    ...new Set(
      text("sizes", 200)
        .split(",")
        .map((size) => size.trim().toUpperCase())
        .filter(Boolean)
    ),
  ];

  if (!team || !season) fail("Enter the team and season.");

  if (!["home", "away", "third"].includes(kit)) {
    fail("Choose Home, Away or Third.");
  }

  if (
    sizes.length === 0 ||
    sizes.length > 20 ||
    sizes.some((size) => !/^[A-Z0-9 -]{1,15}$/.test(size))
  ) {
    fail("Enter valid sizes separated by commas.");
  }

  const price = amount("price");
  const nameFee = amount("name_fee");
  const numberFee = amount("number_fee");

  if (price <= 0) fail("The jersey price must be greater than zero.");

  const supabase = getSupabaseAdmin();

  const { data, error } = await supabase
    .from("products")
    .update({
      jersey_enabled: form.get("enabled") === "on",
      jersey_team: team,
      jersey_season: season,
      jersey_kit: kit,
      jersey_sizes: sizes,
      jersey_name_fee: nameFee,
      jersey_number_fee: numberFee,
      price,
      currency: "NGN",
      sale_mode: "fixed",
    })
    .eq("id", id)
    .select("id")
    .maybeSingle();

  if (error || !data) {
    console.error("[Save jersey settings]", error);
    fail("Jersey settings could not be saved.");
  }

  revalidatePath("/admin/jerseys");
  revalidatePath(`/admin/products/${id}`);
  revalidatePath("/shop/jerseys");

  redirect("/admin/jerseys?saved=1");
}

export default async function AdminJerseysPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string; saved?: string }>;
}) {
  await requireStoreAdmin();

  const query = await searchParams;
  const supabase = getSupabaseAdmin();

  const { data: products, error } = await supabase
    .from("products")
    .select(`
      id, name, price, publication_status,
      jersey_enabled, jersey_team, jersey_season,
      jersey_kit, jersey_sizes,
      jersey_name_fee, jersey_number_fee
    `)
    .order("created_at", { ascending: false })
    .limit(500);

  if (error) throw new Error("Unable to load jersey settings.");

  return (
    <main className="mx-auto max-w-5xl p-5 text-[#181818] sm:p-8">
      <Link
        href="/admin/products"
        className="inline-flex min-h-11 items-center text-sm underline"
      >
        Back to products
      </Link>

      <h1 className="mt-5 text-3xl font-semibold tracking-tight">
        Jersey settings
      </h1>

      <p className="mt-3 max-w-2xl text-sm leading-7 text-[#625D55]">
        Configure one product per team, season and kit. Prices are
        per jersey. Only published products with jersey sales
        enabled appear in the jersey shop.
      </p>

      <Link
        href="/admin/products/new"
        className="mt-4 inline-flex min-h-11 items-center text-sm font-semibold underline"
      >
        Create a product
      </Link>

      {query.error && (
        <p role="alert" className="mt-5 rounded-xl bg-red-50 p-4 text-red-800">
          {query.error}
        </p>
      )}

      {query.saved && (
        <p role="status" className="mt-5 rounded-xl bg-green-50 p-4 text-green-800">
          Jersey settings saved.
        </p>
      )}

      <div className="mt-7 space-y-4">
        {(products ?? []).map((product) => (
          <details
            key={String(product.id)}
            className="rounded-xl border border-black/10 bg-white p-5"
          >
            <summary className="cursor-pointer text-sm font-semibold">
              {product.name}
              <span className="ml-3 text-xs font-normal text-[#625D55]">
                {product.jersey_enabled ? "Jersey enabled" : "Not enabled"}
                {" · "}
                {product.publication_status}
              </span>
            </summary>

            <form action={saveJersey} className="mt-6 grid gap-5 sm:grid-cols-2">
              <input type="hidden" name="product_id" value={String(product.id)} />

              <label className="text-sm font-medium">
                Team
                <input
                  name="team"
                  required
                  maxLength={100}
                  defaultValue={product.jersey_team ?? ""}
                  placeholder="Arsenal"
                  className={field}
                />
              </label>

              <label className="text-sm font-medium">
                Season
                <input
                  name="season"
                  required
                  maxLength={40}
                  defaultValue={product.jersey_season ?? ""}
                  placeholder="2026/27"
                  className={field}
                />
              </label>

              <label className="text-sm font-medium">
                Kit
                <select
                  name="kit"
                  defaultValue={product.jersey_kit ?? "home"}
                  className={field}
                >
                  <option value="home">Home</option>
                  <option value="away">Away</option>
                  <option value="third">Third</option>
                </select>
              </label>

              <label className="text-sm font-medium">
                Available sizes
                <input
                  name="sizes"
                  required
                  maxLength={200}
                  defaultValue={(product.jersey_sizes ?? []).join(", ")}
                  placeholder="S, M, L, XL, XXL"
                  className={field}
                />
              </label>

              {[
                ["price", "Jersey price (NGN)", product.price],
                ["name_fee", "Printed name charge (NGN)", product.jersey_name_fee],
                ["number_fee", "Printed number charge (NGN)", product.jersey_number_fee],
              ].map(([name, label, value]) => (
                <label key={String(name)} className="text-sm font-medium">
                  {label}
                  <input
                    name={String(name)}
                    type="number"
                    min={name === "price" ? "0.01" : "0"}
                    max="99999999.99"
                    step="0.01"
                    required
                    defaultValue={value == null ? "" : String(value)}
                    className={field}
                  />
                </label>
              ))}

              <label className="flex min-h-12 items-center gap-3 text-sm sm:col-span-2">
                <input
                  name="enabled"
                  type="checkbox"
                  defaultChecked={product.jersey_enabled}
                  className="h-5 w-5"
                />
                Enable this product in the jersey shop
              </label>

              <div className="sm:col-span-2">
                <button
                  type="submit"
                  className="min-h-12 rounded-full bg-[#181818] px-6 text-sm font-semibold text-white"
                >
                  Save jersey settings
                </button>
              </div>
            </form>
          </details>
        ))}

        {!products?.length && (
          <p className="text-sm text-[#625D55]">
            Create a product first, then configure its jersey settings here.
          </p>
        )}
      </div>
    </main>
  );
}