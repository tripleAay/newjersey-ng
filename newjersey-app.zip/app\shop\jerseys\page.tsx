import Link from "next/link";
import { ArrowLeft } from "lucide-react";

import DashboardHeader from "@/app/components/dashboard components/mainheader";
import TopNav from "@/app/components/dashboard components/topnav";
import Footer from "@/app/components/Footer";

import { getSupabaseAdmin } from "@/app/lib/newjersey/supabase/admin";
import JerseyOrderForm, { type JerseyProduct } from "./JerseyOrderForm";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "Order Jerseys | NewJersey.ng",
  description:
    "Choose your team, season, kit and size. Personalise your jersey with a printed name and number.",
};

function minor(value: unknown): number | null {
  if (
    value === null ||
    value === undefined ||
    (typeof value !== "number" && typeof value !== "string") ||
    String(value).trim() === ""
  ) {
    return null;
  }

  const amount = Number(value);

  if (!Number.isFinite(amount) || amount < 0 || amount > 99999999.99) {
    return null;
  }

  return Math.round(amount * 100);
}

export default async function JerseysPage() {
  const supabase = getSupabaseAdmin();

  const { data, error } = await supabase
    .from("products")
    .select(`
      id, price, jersey_team, jersey_season,
      jersey_kit, jersey_sizes,
      jersey_name_fee, jersey_number_fee
    `)
    .eq("jersey_enabled", true)
    .eq("publication_status", "published")
    .eq("sale_mode", "fixed")
    .eq("currency", "NGN")
    .order("jersey_team")
    .limit(500);

  if (error) {
    console.error("[Jersey catalogue]", error);
    throw new Error("Unable to load jerseys.");
  }

  const products: JerseyProduct[] = [];

  for (const row of data ?? []) {
    const priceMinor = minor(row.price);

    if (
      priceMinor === null ||
      priceMinor <= 0 ||
      !row.jersey_team ||
      !row.jersey_season ||
      !["home", "away", "third"].includes(row.jersey_kit) ||
      !Array.isArray(row.jersey_sizes) ||
      row.jersey_sizes.length === 0
    ) {
      continue;
    }

    products.push({
      id: String(row.id),
      team: row.jersey_team,
      season: row.jersey_season,
      kit: row.jersey_kit,
      sizes: row.jersey_sizes,
      priceMinor,
      nameFeeMinor: minor(row.jersey_name_fee),
      numberFeeMinor: minor(row.jersey_number_fee),
    });
  }

  return (
    <div className="min-h-screen bg-[#FCFBF8] text-[#181818]">
      <header className="sticky top-0 z-[100] w-full">
        <div className="relative z-[110]">
          <TopNav />
        </div>

        <div className="relative z-[100] bg-[#FCFBF8]/95 shadow-[0_2px_12px_rgba(0,0,0,0.04)] backdrop-blur-md">
          <DashboardHeader />
        </div>
      </header>

      <main className="mx-auto max-w-[1344px] px-5 pb-16 pt-6 sm:px-8 lg:px-12">
        <Link
          href="/shop"
          className="inline-flex min-h-11 items-center gap-2 text-sm text-[#625D55]"
        >
          <ArrowLeft size={16} aria-hidden="true" />
          Back to shop
        </Link>

        <div className="pb-8 pt-6">
          <p className="text-[10px] font-semibold uppercase tracking-[0.2em] text-[#625D55]">
            NewJersey.ng / Jerseys
          </p>

          <h1 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl">
            Your jersey. Your details.
          </h1>

          <p className="mt-3 max-w-xl text-sm leading-7 text-[#625D55]">
            Choose your team and kit, select your size, then add
            a name and number if you want them.
          </p>
        </div>

        <JerseyOrderForm products={products} />
      </main>

      <Footer />
    </div>
  );
}