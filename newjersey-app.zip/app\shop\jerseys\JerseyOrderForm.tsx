"use client";

import Link from "next/link";
import { useRef, useState } from "react";
import { useRouter } from "next/navigation";

import { submitJersey } from "./actions";

export type JerseyProduct = {
  id: string;
  team: string;
  season: string;
  kit: string;
  sizes: string[];
  priceMinor: number;
  nameFeeMinor: number | null;
  numberFeeMinor: number | null;
};

const field =
  "mt-2 min-h-12 w-full rounded-xl border border-black/15 bg-white px-4 py-3 text-base outline-none focus:border-[#B51F2A] focus:ring-2 focus:ring-[#B51F2A]/10";

const money = (minor: number) =>
  new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
  }).format(minor / 100);

export default function JerseyOrderForm({
  products,
}: {
  products: JerseyProduct[];
}) {
  const router = useRouter();
  const busyRef = useRef(false);

  const [team, setTeam] = useState("");
  const [season, setSeason] = useState("");
  const [productId, setProductId] = useState("");
  const [size, setSize] = useState("");
  const [quantity, setQuantity] = useState("1");
  const [wantName, setWantName] = useState(false);
  const [wantNumber, setWantNumber] = useState(false);
  const [printedName, setPrintedName] = useState("");
  const [printedNumber, setPrintedNumber] = useState("");
  const [delivery, setDelivery] = useState("pickup");
  const [confirmed, setConfirmed] = useState(false);
  const [error, setError] = useState("");
  const [submitting, setSubmitting] = useState(false);

  const teams = [...new Set(products.map((product) => product.team))];
  const seasons = [
    ...new Set(
      products.filter((product) => product.team === team)
        .map((product) => product.season)
    ),
  ];

  const kits = products.filter(
    (product) => product.team === team && product.season === season
  );

  const product = kits.find((candidate) => candidate.id === productId);

  const unitMinor = product
    ? product.priceMinor +
      (wantName ? product.nameFeeMinor ?? 0 : 0) +
      (wantNumber ? product.numberFeeMinor ?? 0 : 0)
    : 0;

  const quantityNumber = Number(quantity);
  const quantityValid =
    Number.isInteger(quantityNumber) &&
    quantityNumber >= 1 &&
    quantityNumber <= 100;

  function resetConfirmation() {
    setConfirmed(false);
    setError("");
  }

  async function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();

    if (busyRef.current) return;

    if (!product || !size || !quantityValid || !confirmed) {
      setError("Complete your jersey details and confirm your selections.");
      return;
    }

    const form = new FormData(event.currentTarget);
    busyRef.current = true;
    setSubmitting(true);
    setError("");

    try {
      const result = await submitJersey(form);

      if (result.error) {
        setError(result.error);
        return;
      }

      if (result.orderId) {
        router.push(`/shop/order/${result.orderId}`);
        return;
      }

      setError("Check your orders before submitting again.");
    } catch {
      setError(
        "The order confirmation could not be received. Check your orders before submitting again."
      );
    } finally {
      busyRef.current = false;
      setSubmitting(false);
    }
  }

  if (!products.length) {
    return (
      <p className="rounded-xl border border-black/10 bg-white p-6 text-sm leading-7">
        Jerseys are currently being added. Please check back soon.
      </p>
    );
  }

  return (
    <form
      onSubmit={handleSubmit}
      aria-busy={submitting}
      className="grid items-start gap-8 lg:grid-cols-[minmax(0,1fr)_340px]"
    >
      <fieldset disabled={submitting} className="min-w-0 space-y-6">
        <legend className="sr-only">Your jersey order</legend>

        <section className="rounded-2xl border border-black/10 bg-white p-6">
          <h2 className="text-xl font-semibold">Choose your jersey</h2>

          <div className="mt-6 grid gap-5 sm:grid-cols-2">
            <label className="text-sm font-medium">
              Team *
              <select
                required
                value={team}
                className={field}
                onChange={(event) => {
                  setTeam(event.target.value);
                  setSeason("");
                  setProductId("");
                  setSize("");
                  setWantName(false);
                  setWantNumber(false);
                  resetConfirmation();
                }}
              >
                <option value="">Choose a team</option>
                {teams.map((value) => (
                  <option key={value} value={value}>{value}</option>
                ))}
              </select>
            </label>

            <label className="text-sm font-medium">
              Season *
              <select
                required
                disabled={!team}
                value={season}
                className={field}
                onChange={(event) => {
                  setSeason(event.target.value);
                  setProductId("");
                  setSize("");
                  setWantName(false);
                  setWantNumber(false);
                  resetConfirmation();
                }}
              >
                <option value="">Choose a season</option>
                {seasons.map((value) => (
                  <option key={value} value={value}>{value}</option>
                ))}
              </select>
            </label>

            <label className="text-sm font-medium">
              Kit *
              <select
                name="product_id"
                required
                disabled={!season}
                value={productId}
                className={field}
                onChange={(event) => {
                  setProductId(event.target.value);
                  setSize("");
                  setWantName(false);
                  setWantNumber(false);
                  resetConfirmation();
                }}
              >
                <option value="">Choose a kit</option>
                {kits.map((kit) => (
                  <option key={kit.id} value={kit.id}>
                    {kit.kit.charAt(0).toUpperCase() + kit.kit.slice(1)}
                    {" — "}{money(kit.priceMinor)}
                  </option>
                ))}
              </select>
            </label>

            <label className="text-sm font-medium">
              Size *
              <select
                name="size"
                required
                disabled={!product}
                value={size}
                className={field}
                onChange={(event) => {
                  setSize(event.target.value);
                  resetConfirmation();
                }}
              >
                <option value="">Choose a size</option>
                {product?.sizes.map((value) => (
                  <option key={value} value={value}>{value}</option>
                ))}
              </select>
            </label>

            <label className="text-sm font-medium">
              Quantity *
              <input
                name="quantity"
                type="number"
                min={1}
                max={100}
                required
                value={quantity}
                className={field}
                onChange={(event) => {
                  setQuantity(event.target.value);
                  resetConfirmation();
                }}
              />
            </label>
          </div>

          <p className="mt-4 text-xs leading-6 text-[#625D55]">
            Multiple pieces will have the same size, printed name and
            number. Submit separate orders for different personalisations.
          </p>
        </section>

        <section className="rounded-2xl border border-black/10 bg-white p-6">
          <h2 className="text-xl font-semibold">Make it personal</h2>

          <label className="mt-5 flex min-h-11 items-center gap-3 text-sm">
            <input
              type="checkbox"
              checked={wantName}
              disabled={!product || product.nameFeeMinor === null}
              onChange={(event) => {
                setWantName(event.target.checked);
                resetConfirmation();
              }}
              className="h-5 w-5"
            />
            Add a printed name
            {product?.nameFeeMinor != null &&
              ` (+${money(product.nameFeeMinor)} each)`}
          </label>

          {wantName && (
            <label className="mt-3 block text-sm font-medium">
              Name to print *
              <input
                name="printed_name"
                required
                maxLength={30}
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                value={printedName}
                className={field}
                onChange={(event) => {
                  setPrintedName(event.target.value);
                  resetConfirmation();
                }}
              />
            </label>
          )}

          {!wantName && <input type="hidden" name="printed_name" value="" />}

          <label className="mt-5 flex min-h-11 items-center gap-3 text-sm">
            <input
              type="checkbox"
              checked={wantNumber}
              disabled={!product || product.numberFeeMinor === null}
              onChange={(event) => {
                setWantNumber(event.target.checked);
                resetConfirmation();
              }}
              className="h-5 w-5"
            />
            Add a printed number
            {product?.numberFeeMinor != null &&
              ` (+${money(product.numberFeeMinor)} each)`}
          </label>

          {wantNumber && (
            <label className="mt-3 block text-sm font-medium">
              Number to print *
              <input
                name="printed_number"
                type="text"
                inputMode="numeric"
                pattern="[0-9]{1,3}"
                maxLength={3}
                required
                value={printedNumber}
                className={field}
                onChange={(event) => {
                  setPrintedNumber(event.target.value);
                  resetConfirmation();
                }}
              />
            </label>
          )}

          {!wantNumber && (
            <input type="hidden" name="printed_number" value="" />
          )}

          <p className="mt-5 rounded-xl bg-[#F4F1E9] p-4 text-xs leading-6">
            <strong>Names are case-sensitive.</strong> SHINE, Shine
            and shine print differently. Enter names and numbers
            exactly as you want them printed. Leading zeros such
            as 07 will be preserved.
          </p>

          <label className="mt-5 block text-sm font-medium">
            Additional instructions
            <textarea
              name="instructions"
              rows={4}
              maxLength={2000}
              className={field}
              placeholder="Printing colour, placement or other details"
            />
          </label>
        </section>

        <section className="rounded-2xl border border-black/10 bg-white p-6">
          <h2 className="text-xl font-semibold">Your details</h2>

          <div className="mt-6 grid gap-5 sm:grid-cols-2">
            <label className="text-sm font-medium">
              Full name *
              <input name="full_name" autoComplete="name" required maxLength={150} className={field} />
            </label>

            <label className="text-sm font-medium">
              Phone number *
              <input name="phone" type="tel" autoComplete="tel" required maxLength={40} className={field} />
            </label>

            <label className="text-sm font-medium sm:col-span-2">
              Email *
              <input name="email" type="email" autoComplete="email" required maxLength={254} className={field} />
            </label>

            <label className="text-sm font-medium sm:col-span-2">
              Delivery or pickup
              <select
                name="delivery_method"
                value={delivery}
                onChange={(event) => setDelivery(event.target.value)}
                className={field}
              >
                <option value="pickup">I will arrange pickup</option>
                <option value="delivery">Deliver to me</option>
              </select>
            </label>

            {delivery === "delivery" ? (
              <>
                <label className="text-sm font-medium">
                  State *
                  <input name="state" required maxLength={100} className={field} />
                </label>
                <label className="text-sm font-medium">
                  City *
                  <input name="city" required maxLength={100} className={field} />
                </label>
                <label className="text-sm font-medium sm:col-span-2">
                  Address *
                  <textarea name="address" required maxLength={500} rows={3} className={field} />
                </label>
              </>
            ) : (
              <>
                <input type="hidden" name="state" value="" />
                <input type="hidden" name="city" value="" />
                <input type="hidden" name="address" value="" />
              </>
            )}
          </div>
        </section>
      </fieldset>

      <aside className="rounded-2xl border border-black/10 bg-white p-6 lg:sticky lg:top-44">
        <h2 className="text-xl font-semibold">Your jersey order</h2>

        <dl className="mt-5 space-y-3 text-sm">
          {[
            ["Team", team || "Choose a team"],
            ["Season", season || "—"],
            ["Kit", product?.kit || "—"],
            ["Size", size || "—"],
            ["Quantity", quantity || "—"],
            ["Printed name", wantName ? printedName || "Enter a name" : "None"],
            ["Printed number", wantNumber ? printedNumber || "Enter a number" : "None"],
            ["Jersey each", product ? money(product.priceMinor) : "—"],
            ["Name each", money(wantName ? product?.nameFeeMinor ?? 0 : 0)],
            ["Number each", money(wantNumber ? product?.numberFeeMinor ?? 0 : 0)],
          ].map(([label, value]) => (
            <div key={label} className="flex justify-between gap-4">
              <dt className="text-[#625D55]">{label}</dt>
              <dd className="break-words text-right">{value}</dd>
            </div>
          ))}

          <div className="flex justify-between gap-4 border-t border-black/10 pt-4">
            <dt className="font-semibold">Jersey total</dt>
            <dd className="text-xl font-semibold">
              {product && quantityValid
                ? money(unitMinor * quantityNumber)
                : "—"}
            </dd>
          </div>
        </dl>

        <input type="hidden" name="expected_unit_minor" value={unitMinor} />

        <p className="mt-4 text-xs leading-6 text-[#625D55]">
          Delivery is excluded. We will confirm availability and
          your final order total before payment.
        </p>

        <label className="mt-5 flex items-start gap-3 text-xs leading-6">
          <input
            name="confirmed"
            type="checkbox"
            required
            checked={confirmed}
            disabled={submitting}
            onChange={(event) => setConfirmed(event.target.checked)}
            className="mt-1 h-4 w-4 shrink-0"
          />
          I have checked the team, season, kit, size, spelling,
          capitalisation and number.
        </label>

        {error && (
          <p role="alert" className="mt-4 rounded-xl bg-red-50 p-4 text-sm text-red-800">
            {error}
          </p>
        )}

        <button
          type="submit"
          disabled={submitting || !product || !size || !quantityValid}
          className="mt-6 min-h-12 w-full rounded-full bg-[#B51F2A] px-5 text-sm font-semibold text-white disabled:cursor-not-allowed disabled:opacity-50"
        >
          {submitting ? "Submitting your order…" : "Submit jersey order"}
        </button>

        <Link
          href="/login?next=%2Fshop%2Fjerseys"
          className="mt-4 block text-center text-xs underline underline-offset-4"
        >
          Sign in to submit your order
        </Link>
      </aside>
    </form>
  );
}