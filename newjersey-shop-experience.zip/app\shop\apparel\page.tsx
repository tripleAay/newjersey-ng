import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import StoreShell from "@/app/components/newjersey/storefront/StoreShell";
import CollectionBrowser from "@/app/components/newjersey/storefront/CollectionBrowser";
import { loadApparel } from "@/app/lib/newjersey/storefront/load";
export const dynamic = "force-dynamic";
export const metadata = {
  title: "Apparel | NewJersey.ng",
  description:
    "Ready-designed clothing. Find your design, choose your size and colour, and add it to your cart.",
};
export default async function CollectionPage() {
  const products = await loadApparel();
  return (
    <StoreShell>
      <main className="mx-auto max-w-[1344px] px-4 pb-16 pt-5 sm:px-8 lg:px-12">
        <Link
          href="/shop"
          className="inline-flex min-h-11 items-center gap-2 text-xs text-[#625D55]"
        >
          <ArrowLeft size={15} />
          Back to shop
        </Link>
        <div className="pb-7 pt-6">
          <p className="text-[10px] font-semibold uppercase tracking-[.2em] text-[#FF6B00]">
            NewJersey.ng / apparel
          </p>
          <h1 className="mt-3 text-3xl font-semibold tracking-tight sm:text-4xl">
            Good clothes. Your choice.
          </h1>
          <p className="mt-3 max-w-xl text-sm leading-7 text-[#625D55]">
            Ready-designed clothing. Find your design, choose your size and
            colour, and add it to your cart.
          </p>
        </div>
        <CollectionBrowser products={products} department="apparel" />
      </main>
    </StoreShell>
  );
}
